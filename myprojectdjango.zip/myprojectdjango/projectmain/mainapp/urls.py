from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'), # Главная
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('notes/', views.notes_view, name='notes'), # Страница заметок
    
    # API для JavaScript
    path('api/login/', views.api_login, name='api_login'),
    path('api/notes/', views.api_notes, name='api_notes'),
    path('api/notes/<int:pk>/', views.api_note_detail, name='api_note_detail'),
    
    # УДАЛИТЕ ИЛИ ЗАКОММЕНТИРУЙТЕ ЭТИ ДВЕ СТРОКИ:
    # path('delete/<int:pk>/', views.delete_task, name='delete_task'),
    # path('edit/<int:pk>/', views.edit_task, name='edit_task'),
]
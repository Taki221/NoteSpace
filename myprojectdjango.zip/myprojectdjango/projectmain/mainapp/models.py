from django.db import models
from django.contrib.auth.models import User

class Task(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True) # Привязка к юзеру
    title = models.CharField(max_length=100)
    content = models.TextField(blank=True, null=True) # Заменили description на content
    is_favorite = models.BooleanField(default=False) # Для избранного
    is_deleted = models.BooleanField(default=False)  # Для корзины
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.title
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate # Добавили authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Task
from .forms import TaskForm

# --- ОБЫЧНЫЕ СТРАНИЦЫ (HTML) ---
def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'mainapp/login.html', {'form': form})

@login_required(login_url='login')
def notes_view(request):
    # Эта функция просто отдает HTML-файл Notes.html
    return render(request, 'mainapp/notes.html') 

@login_required(login_url='login')
def index(request):
    # (Оставляем ваш старый код index, если он нужен для другой страницы)
    tasks = Task.objects.filter(user=request.user)
    form = TaskForm()
    return render(request, 'mainapp/index.html', {'tasks': tasks, 'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

# --- API ДЛЯ JS ---

@csrf_exempt
def api_login(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return JsonResponse({'status': 'ok'})
        return JsonResponse({'error': 'Invalid credentials'}, status=400)

@csrf_exempt
def api_notes(request):
    if request.method == 'GET':
        # Фильтруем заметки только текущего пользователя
        notes = list(Task.objects.filter(user=request.user).values())
        return JsonResponse(notes, safe=False)
        
    elif request.method == 'POST':
        data = json.loads(request.body)
        new_note = Task.objects.create(
            title=data.get('title'),
            content=data.get('content'), # Используем content
            user=request.user
        )
        return JsonResponse({'id': new_note.id, 'status': 'ok'})

@csrf_exempt
def api_note_detail(request, pk):
    try:
        note = Task.objects.get(pk=pk, user=request.user) # Проверяем, что заметка принадлежит юзеру
    except Task.DoesNotExist:
        return JsonResponse({'error': 'Not found'}, status=404)
        
    if request.method == 'PUT':
        data = json.loads(request.body)
        note.title = data.get('title', note.title)
        note.content = data.get('content', note.content)
        note.is_favorite = data.get('isFavorite', note.is_favorite)
        note.is_deleted = data.get('isDeleted', note.is_deleted)
        note.updated_at = timezone.now()
        note.save()
        return JsonResponse({'status': 'ok'})
        
    elif request.method == 'DELETE':
        note.delete()
        return JsonResponse({'status': 'ok'})